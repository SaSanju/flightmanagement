swift-airline-reservation-system
================================

Swift Airline Reservation System has been built using PHP &amp; MySQL as a part of 7th semester project for Software Engineering (CS0401)
