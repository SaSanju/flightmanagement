<!DOCTYPE html>

<html lang="en">

<?php include $_SERVER["DOCUMENT_ROOT"].'/swift/includes/head.php'; ?> 

    <!-- Website body placed here -->

    <body>
    <?php include $_SERVER["DOCUMENT_ROOT"].'/swift/includes/navbar.php'; ?> 
                            
        <!-- Website body and container are wrapped here -->

        <br/><br/><br/>

    <div class="container">        