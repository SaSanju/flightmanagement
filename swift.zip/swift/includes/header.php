        
        <!-- Website header placed here -->

        <header>
        <div class="container">
           <img src="./bootstrap/img/banner.png" height="100%" width="100%">
           </div>
        </header>