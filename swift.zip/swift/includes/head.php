<!-- Website head placed here -->
    
<head>

    <meta charset="utf-8">

    <title><?php if (isset($title)) {echo $title;}
        else {echo "Air India";} ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="./vendor/css/bootstrap.min.css" media="screen">
    <link rel="stylesheet" href="./vendor/css/bootswatch.min.css">

    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="//code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
    <link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" />
    <script src="./vendor/js/bootstrap.min.js"></script>
    <!--<script type="text/javascript" src="./vendor/js/jquery/dist/jquery.js"></script>-->
    <script src="./vendor/js/bootswatch.js"></script>
    <script type="text/javascript">
               	$(document).ready(function(){
               	     $("#departure_date").datepicker({
          					     maxDate: 30,
          					     minDate: 0,
          					     dateFormat:"dd-mm-yy"
          					  });
                      $("#return_date").datepicker({
          					     maxDate: 30,
          					     minDate: 1,
          					     dateFormat:"dd-mm-yy"
          					  });
                });
               	function setReadOnly(obj){
				   if(obj.value == "oneway"){
				     $('#departure_date').datepicker('enable');
				     $('#return_date').datepicker('disable');
				   } 
				   else {
				     $('#departure_date').datepicker('enable');
				     $('#return_date').datepicker('enable');
				   }
				}
          $(function() {
            var availableTags = [
            "Chennai","Delhi","Kolkata","Mumbai"
            ];
            $( "#from_city" ).autocomplete({
            source: availableTags
            });
          });
          $(function() {
            var availableTags = [
            "Chennai","Delhi","Kolkata","Mumbai"
            ];
            $( "#to_city" ).autocomplete({
            source: availableTags
            });
          });
       </script>

      <script type="text/javascript">
          $(document).ready(function() {	

          var id = '#dialog';
        
          //Get the screen height and width
          var maskHeight = $(document).height();
          var maskWidth = $(window).width();
        
          //Set heigth and width to mask to fill up the whole screen
          $('#mask').css({'width':maskWidth,'height':maskHeight});
          
          //transition effect		
          $('#mask').fadeIn(1000);	
          $('#mask').fadeTo("slow",0.8);	
        
          //Get the window height and width
          var winH = $(window).height();
          var winW = $(window).width();
                    
          //Set the popup window to center
          $(id).css('top',  winH/2-$(id).height()/2);
          $(id).css('left', winW/2-$(id).width()/2);
        
          //transition effect
          $(id).fadeIn(2000); 	
        
          //if close button is clicked
          $('.window .close').click(function (e) {
            //Cancel the link behavior
            e.preventDefault();
            
            $('#mask').hide();
            $('.window').hide();
          });		
          
          //if mask is clicked
          $('#mask').click(function () {
            $(this).hide();
            $('.window').hide();
          });		
          
      });
      </script>

      <style type="text/css">
        body {
        font-family:verdana;
        font-size:15px;
        }

        #boxes a {color:#333; margin-right:-25px; margin-top:-25px; text-decoration:none}
        #boxes a:hover {color:#ccc; text-decoration:none}

        #mask {
          position:absolute;
          left:0;
          top:0;
          z-index:9000;
          background-color:#000;
          display:none;
        }  
        #boxes .window {
          position:absolute;
          left:0;
          top:0;
          width:440px;
          height:200px;
          display:none;
          z-index:9999;
          padding:20px;
        }
        #boxes #dialog {
          width:375px; 
          height:203px;
          padding:10px;
          background-color:#ffffff;
        }
      </style>
       
</head>