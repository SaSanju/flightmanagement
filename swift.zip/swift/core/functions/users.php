<?php


	function f_recover($mode, $f_mailid) {
		$mode = sanitize($mode);
		$f_mailid = sanitize($f_mailid);
		$f_data = f_data(f_id_from_email($f_mailid),'f_id','f_fname','f_uname');
		if ($mode == 'f_uname') {
			recovery_user_pass($f_mailid, 'Recovery: Your username', "Hello " . $f_data['f_fname'] . ",\n\nYour username is: " . $f_data['f_uname'] . "\n\n-Swift Airlines");
		}
		else if($mode == 'f_password') {
			$generated_password = substr(md5(rand(999, 999999)), 0, 8);
			f_change_password($f_data['f_id'], $generated_password);
			
			update_f($f_data['f_id'], array('f_passrec' => '1'));
			
			recovery_user_pass($f_mailid, 'Recovery: Your password', "Hello " . $f_data['f_fname'] . ",\n\nYour new password is: " . $generated_password . "\n\n-TOFSIS");
		}
	}

	// function f_activate($f_mailid, $f_mailcode) {
	// 	$f_mailid = mysql_real_escape_string($f_mailid);
	// 	$f_mailcode = mysql_real_escape_string($f_mailcode);
	// 	if(mysql_result(mysql_query("SELECT COUNT(`f_id`) FROM `flight_users` WHERE `f_mailid` = '$f_mailid' AND `f_mailcode` = '$f_mailcode' AND `f_active` = 0"), 0) == 1) {
	// 		mysql_query("UPDATE `flight_users` SET `f_active` = 1 WHERE `f_mailid` = '$f_mailid' ");
	// 		return true;
	// 	}
	// 	else {
	// 		return false;
	// 	}
	// }
	
	function update_f($f_id, $update_data) {
		$update = array();
		array_walk($update_data, 'array_sanitize');
		foreach ($update_data as $field => $data) {
			$update[] = '`' . $field . '` = \'' . $data . '\'';
		}		
		mysql_query("UPDATE `flight_users` SET " . implode(', ',$update) . "WHERE `f_id` = $f_id") or die(mysql_error());
	}

	function f_change_password($f_id, $f_password) {
		$f_id = (int)$f_id;
		$f_password = md5($f_password);
		mysql_query("UPDATE `flight_users` SET `f_password` = '$f_password', `f_passrec` = 0 WHERE `f_id` = $f_id");
	}

	function register_f($register_data) {
        $columns = implode(", ",array_keys($register_data));
        $escaped_values = array_map('mysql_real_escape_string', array_values($register_data));
        foreach ($escaped_values as $idx=>$data) $escaped_values[$idx] = "'".$data."'";
        $values  = implode(", ", $escaped_values);
        $query = "INSERT INTO flight_users ($columns) VALUES ($values)";
        mysql_query($query) or die(mysql_error());
	}

	function f_data($f_id){
		$data = array();
		$f_id = (int)$f_id;
		$func_num_args = func_num_args();
		$func_get_args = func_get_args();
		if($func_num_args > 1) {
			unset($func_get_args[0]);
			$fields = '`'. implode('`, `', $func_get_args) . '`'; 
			$data = mysql_fetch_assoc(mysql_query("SELECT $fields FROM `flight_users` WHERE `f_id` = $f_id"));			
			return $data;
		}
 	}
 	
	function f_logged_in() {
		return (isset($_SESSION['f_id'])) ? true : false;
	}

	function f_exists($f_uname) {
		$f_uname = sanitize($f_uname);
		$query = mysql_query("SELECT COUNT(`f_id`) FROM `flight_users` WHERE `f_uname`= '$f_uname'");
		return (mysql_result($query, 0) == 1) ? true : false; 
	}

	function f_email_exists($f_mailid) {
		$f_mailid = sanitize($f_mailid);
		$query = mysql_query("SELECT COUNT(`f_id`) FROM `flight_users` WHERE `f_mailid`= '$f_mailid'");
		return (mysql_result($query, 0) == 1) ? true : false; 
	}
	
	// function f_regid_exists($f_regid) {
	// 	$f_regid = sanitize($f_regid);
	// 	$query = mysql_query("SELECT COUNT(`f_id`) FROM `flight_users` WHERE `f_regid`= '$f_regid'");
	// 	return (mysql_result($query, 0) == 1) ? true : false; 
	// }

	// function f_active($f_uname) {
	// 	$f_uname = sanitize($f_uname);
	// 	$query = mysql_query("SELECT COUNT(`f_id`) FROM `flight_users` WHERE `f_uname`= '$f_uname'");
	// 	return (mysql_result($query, 0) == 1) ? true : false; 
	// }

	function f_id_from_username($f_uname) {
		$f_uname = sanitize($f_uname);
		$query = mysql_query("SELECT `f_id` FROM `flight_users` WHERE `f_uname` = '$f_uname'");
		return mysql_result($query, 0, 'f_id');
	} 
	
	function f_id_from_email($f_mailid) {
		$f_mailid = sanitize($f_mailid);
		$query = mysql_query("SELECT `f_id` FROM `flight_users` WHERE `f_mailid` = '$f_mailid'");
		return mysql_result($query, 0, 'f_id');
	} 
	
	function f_login($f_uname, $f_password) {
		$f_id = f_id_from_username($f_uname);
		$f_uname = sanitize($f_uname);
		$f_password = $f_password;
		$query = mysql_query("SELECT COUNT(`f_id`) FROM `flight_users` WHERE `f_uname`= '$f_uname' AND `f_password` = '$f_password'");
		return (mysql_result($query, 0) == 1) ? $f_id : false;
	}

	// Check connection
	function display_last_visit() {
		$cart = array();
	
	if (getenv('HTTP_X_FORWARDED_FOR')) {
			$pipaddress = getenv('HTTP_X_FORWARDED_FOR');
			$ipaddress = getenv('REMOTE_ADDR');
		} else {
			$ipaddress = getenv('REMOTE_ADDR');
		}
		$result = mysql_query("SELECT * FROM track WHERE ip = '$ipaddress';") or die(mysql_error());
		$count = mysql_num_rows($result);
		if($count > 0){
		//$count = mysql_num_rows($result);
  
		$i=0;
		while($i<$count)
		{
		$record = mysql_fetch_assoc($result);
		//print_r($record['fl_no']);
		//echo $record['fl_no'];
		$r['i'] = get_ip($record['fl_no']);
		array_push($cart, $r['i']);
		$i++;
		}
		return $cart;
		}
		else{
			echo 'First Time Visit !';
		}
		//$ip = ip2long($ipaddress);
		//mysql_query("INSERT IGNORE INTO track (ip) VALUES ('$ipaddress')") or die(mysql_error());
	
	}
		class Car
			{
				public $color;
				public $type;
			}
	


	function get_ip($data) {

		$result = mysql_query("SELECT * FROM flight_search WHERE fno = '$data';") or die(mysql_error());
		$val = mysql_fetch_assoc($result);
		
		$myCar = new Car();
		$myCar->color = $val['fno'];
		$myCar->type = $val['e_price'];
		return  $myCar;
		//echo $val['fno'] .'--'. $val['e_price'];
	}

	function RandImg($dir)
	{
	$images = glob($dir . '*.{jpg,jpeg,png,gif}', GLOB_BRACE);

	$randomImage = $images[array_rand($images)];
	return $randomImage;
	}

?>