<?php

	$connect_error = 'Sorry, there was some connectivity issue!';
	@mysql_connect('localhost','root','mysql') or die($connect_error);
	@mysql_select_db('flights') or die($connect_error);

?>